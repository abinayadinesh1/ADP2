import "package:flutter/material.dart";

class DetailPage extends StatelessWidget{
  final int index;

  DetailPage(this.index);

  @override 
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('Details'),
      ),
      body: new Center(
        child: 
          Text.rich(
            TextSpan(
              children: <TextSpan>[
                TextSpan(text: 'Details of your event\n', style: TextStyle(color: Colors.green[300], fontSize: 30)),
                TextSpan(text: 'Date of Event: November 3, 2020\n\n', style: TextStyle(color: Colors.black, fontSize: 20)),
                TextSpan(text: 'Description: This was a JA event meant to strengthen community in the area by building bonds and connections. At the event, volunteers helped by organizing the area and distributing materials to those present.\n\n', style: TextStyle(color: Colors.black, fontSize: 20)),
                TextSpan(text: 'Administrator Present: Abinaya Dinesh\n\n', style: TextStyle(color: Colors.black, fontSize: 20)),
              ]
            )
          )
        ),
      );
        }

}