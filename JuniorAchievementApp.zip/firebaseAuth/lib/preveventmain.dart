import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import "package:firebaseAuth/preveventdetails.dart";

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attended Events',
      theme: ThemeData(
        visualDensity: 
        VisualDensity.adaptivePlatformDensity,
        primarySwatch: Colors.green,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Attended Events",
          ),
              ),
              body: _buildListView(context),
    );
  }
  ListView _buildListView(BuildContext context){
    final events = ["JA South Women's Future Leadership Forum", "Virtual 4.01K for JANJ","JA Titan Challenge", "A Taste of the Decades", "JA Bowl A Thon" ];

    return ListView.builder(
      itemCount: events.length,
      itemBuilder: (_, index){
        return Card(
          child: 
            ListTile(
              title: Text(events[index]),
              subtitle: Text("You've attended the event and recieved a total of 2 hours."),
              leading: Icon(Icons.event_available),
              trailing: IconButton(
                icon: Icon(Icons.arrow_forward),
                onPressed: (){
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DetailPage(index),
                  ),
                );
                },
                ),
            ),);


      },
    );
  }
}