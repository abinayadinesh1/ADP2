import 'package:flutter/material.dart';
import 'package:firebaseAuth/controller.dart';
import 'package:firebaseAuth/model/form.dart';
import 'package:firebaseAuth/firebaseAuthDemo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseAuth/preveventmain.dart';


class MainPage extends StatefulWidget {
  final User user;

  const MainPage({Key key, this.user}) : super(key: key);
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  FirebaseAuth _auth = FirebaseAuth.instance;

  final _formKey = GlobalKey<FormState>();
  //final _scaffoldKey = GlobalKey<ScaffoldState>();

  // TextField Controllers
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController eventController = TextEditingController();
  TextEditingController hoursController = TextEditingController();

  void _submitForm() {

    if(_formKey.currentState.validate()){
      FeedbackForm feedbackForm = FeedbackForm(
          nameController.text,
          emailController.text,
          eventController.text,
          hoursController.text
      );

      FormController formController = FormController((String response){
        print("Response: $response");
        if(response == FormController.STATUS_SUCCESS){
          //
          _showSnackbar("Feedback Submitted");
        } else {
          _showSnackbar("Error Occurred!");
        }
      });

      _showSnackbar("Submitting Feedback");

      // Submit 'feedbackForm' and save it in Google Sheet

      formController.submitForm(feedbackForm);
    }


  }

  // Method to show snackbar with 'message'.
  _showSnackbar(String message) {
    final snackBar = SnackBar(content: Text(message));
    _scaffoldKey.currentState.showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Events"),
      ),
      key:  _scaffoldKey,
      body: Center(
        child: Container(
          color: Colors.lightGreen,
          padding: EdgeInsets.symmetric(vertical: 50,horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    TextFormField(
                      controller: nameController,
                      validator: (value){
                        if(value.isEmpty){
                          return "Enter Valid Name";
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                        labelText: "Name"
                      ),
                    ),
                    TextFormField(
                      controller: emailController,
                      validator: (value){
                        if(value.isEmpty){
                          return "Enter Valid Email";
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                          labelText: "Email"
                      ),
                    ),
                    TextFormField(
                      controller: eventController,
                      validator: (value){
                        if(value.isEmpty){
                          return "Enter Name of Event";
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                          labelText: "Event"
                      ),
                    ),
                    TextFormField(
                      controller: hoursController,
                      validator: (value){
                        if(value.isEmpty){
                          return "Enter Amount of Hours";
                        }
                        return null;
                      },
                      decoration: InputDecoration(
                          labelText: "Hours"
                      ),
                    ),
                    RaisedButton(
                      color: Colors.grey,
                      textColor: Colors.black,
                      onPressed: _submitForm,
                      child: Text('Submit'),

                    ),
                    RaisedButton(
                      color: Colors.grey,
                      textColor: Colors.black,
                        child: Text('Previous Events'),
                      onPressed: () {
                        _signOut().whenComplete(() {
                          Navigator.of(context).pushReplacement(
                              MaterialPageRoute(
                                  builder: (context) => MyApp()));
                        });
                      }
                    )

                  ],
                ),
              )
            ],
          ),
        ),
      ),

    );
  }

  Future _signOut() async {
    await _auth.signOut();
  }
}
