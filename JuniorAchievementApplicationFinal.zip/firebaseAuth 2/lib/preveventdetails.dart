import "package:flutter/material.dart";
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebaseAuth/firebaseAuthDemo.dart';


class DetailPage extends StatelessWidget{
  final int index;
  FirebaseAuth _auth = FirebaseAuth.instance;
  DetailPage(this.index);

  @override

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,
      appBar: AppBar(
        backgroundColor: Color(0xff05B068),
        title: Text("Event Detail Page"),
        textTheme: TextTheme(
            title: TextStyle(
              color: Colors.white,
              fontSize: 40.0,
            )
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[

          Container(
              child: Text.rich(
                  TextSpan(
                      children: <TextSpan>[
                        TextSpan(text: 'Details of your event\n',
                            style: TextStyle(
                                color: Colors.green[300], fontSize: 30)),
                        TextSpan(text: 'Date of Event: November 3, 2020\n\n',
                            style: TextStyle(
                                color: Colors.black, fontSize: 20)),
                        TextSpan(
                            text: 'Description: This was a JA event meant to strengthen community in the area by building bonds and connections. At the event, volunteers helped by organizing the area and distributing materials to those present.\n\n',
                            style: TextStyle(
                                color: Colors.black, fontSize: 20)),
                        TextSpan(
                            text: 'Administrator Present: Abinaya Dinesh\n\n',
                            style: TextStyle(
                                color: Colors.black, fontSize: 20)),

                      ]

                  )
              )
          ),

          Container(
              child: new ButtonBar(
                  alignment: MainAxisAlignment.center,
                  children: <Widget>[
                    new RaisedButton(
                      child: Text("SignOut"),

                      onPressed: () => _pushPage(context, FirebaseAuthDemo()),
                    ),

                  ]
              )
          )
        ],
      ),
    );
  }

  void _pushPage(BuildContext context, Widget page) {
    _signOut();
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }

    Future _signOut() async {
    await _auth.signOut();
    }

}