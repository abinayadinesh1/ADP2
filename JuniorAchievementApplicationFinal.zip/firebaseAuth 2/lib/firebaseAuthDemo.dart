import 'package:firebaseAuth/regster.dart';
import 'package:firebaseAuth/signIn.dart';
import 'package:flutter/material.dart';

class FirebaseAuthDemo extends StatefulWidget {
  @override
  _FirebaseAuthDemoState createState() => _FirebaseAuthDemoState();
}

class _FirebaseAuthDemoState extends State<FirebaseAuthDemo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green,
      appBar: AppBar(
        backgroundColor: Color(0xff05B068),
        title: Text("Home Page"),
        textTheme: TextTheme(
          title: TextStyle(
              color: Colors.white,
              fontSize: 40.0,
          )
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
              child: Text('Upcoming Events:',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                  fontSize: 40,
                ),
              ),
              alignment: Alignment.topCenter
          ),
          Container(
            child: Text('\nOctober: ',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
                fontSize: 30,
              ),
            ),
              alignment: Alignment.topLeft
          ),
          Container(
              child: Text('1. Personal Finance on 10/15/2020 \n 2. Job Shadow on 10/29/2020',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                  fontSize: 15,
                ),
              ),
              alignment: Alignment.topLeft,
          ),
          Container(
              child: Text('November: ',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                  fontSize: 30,
                ),
              ),
              alignment: Alignment.topLeft
          ),
          Container(
            child: Text('1. BizTown on 11/19/2020',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
                fontSize: 15,
              ),
            ),
            alignment: Alignment.topLeft,
          ),
          Container(
              child: Text('December: ',
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'OpenSans',
                  fontSize: 30,
                ),
              ),
              alignment: Alignment.topLeft
          ),
          Container(
            child: Text('1. Career Exploration on 12/01/2020 \n 2. Finance Park on 12/12/2020\n\n',
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'OpenSans',
                fontSize: 15,
              ),
            ),
            alignment: Alignment.topLeft,
          ),
          Container(
            child: new ButtonBar(
              alignment: MainAxisAlignment.center,
              children: <Widget>[
                new RaisedButton(
                  child: Text("Login"),
                  onPressed: () => _pushPage(context, SignIn()),
                ),
                new RaisedButton(
                  child: Text("Sign Up"),
                  onPressed: () => _pushPage(context, Register()),
                ),
              ]
            )
          )
        ],
      ),
    );
  }

  void _pushPage(BuildContext context, Widget page) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }
}
