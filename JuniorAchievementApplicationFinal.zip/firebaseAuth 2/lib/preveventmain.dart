import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import "package:firebaseAuth/preveventdetails.dart";
import 'package:firebase_auth/firebase_auth.dart';


  class EventPage extends StatelessWidget{
  //final int index;
  FirebaseAuth _auth = FirebaseAuth.instance;
 // DetailPage(this.index);
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff05B068),
        title: Text("Previous Events"),
        textTheme: TextTheme(
            title: TextStyle(
              color: Colors.white,
              fontSize: 40.0,
            )
        ),
      ),
              body: _buildListView(context),
    );
  }


  ListView _buildListView(BuildContext context){
    final events = ["JA South Women's Future Leadership Forum", "Virtual 4.01K for JANJ","JA Titan Challenge", "A Taste of the Decades", "JA Bowl A Thon" ];

    return ListView.builder(
      itemCount: events.length,
      itemBuilder: (_, index){
        return Card(
          child: 
            ListTile(
              title: Text(events[index]),
              subtitle: Text("You've attended the event and recieved a total of 2 hours."),
              leading: Icon(Icons.event_available),
              trailing: IconButton(
                icon: Icon(Icons.arrow_forward),
                onPressed: (){
                  Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DetailPage(index),
                  ),
                );
                },
                ),
            ),);


      },
    );
  }
}