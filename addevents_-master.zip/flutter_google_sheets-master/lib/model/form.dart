import 'package:flutter/cupertino.dart';

class FeedbackForm {

  String _name;
  String _email;
  String _event;
  String _hours;

  FeedbackForm(this._name, this._email, this._event, this._hours);

  // Method to make GET parameters.
  String toParams() =>
      "?name=$_name&email=$_email&event=$_event&hours=$_hours";

}